from student import Student
from group import Group, GroupLimitError

st1 = Student('Male', 30, 'Steve', 'Jobs', 'AN142')
st2 = Student('Female', 25, 'Liza', 'Taylor', 'AN145')
gr = Group('PD1')

try:
    gr.add_student(st1)
    gr.add_student(st2)
    print(gr)
    
    assert gr.find_student('Jobs') == st1, 'Test1'
    assert gr.find_student('Jobs2') is None, 'Test2'

    gr.delete_student('Taylor')
    print(gr)  # Only one student remains

    # Adding 8 more students to reach the limit
    for i in range(3, 11):
        gr.add_student(Student('Male', 20+i, f'Student{i}', f'LastName{i}', f'AN1{i+40}'))

    # Attempt to add the 11th student
    gr.add_student(Student('Male', 22, 'Tom', 'Anderson', 'AN154'))

except GroupLimitError as e:
    print(e)
